export type RecordType = 'investment' | 'sale' | 'purchase' | 'expense' | 'withdrawal' | 'other';
export type Role = 'admin' | 'investor';
export interface Investor { id: string; name: string; phone?: string; active: boolean; createdAt?: string }
export interface Entry {
  id: string;
  type: RecordType;
  title: string;
  amount: number;
  date: string;
  investorId?: string;
  category?: string;
  notes?: string;
  status: 'draft' | 'posted' | 'void';
  demo?: boolean;
  createdAt?: string;
  createdBy?: string;
}
export interface BusinessSettings { name: string; type: string; address: string; phone: string }