import type { Entry, Investor } from './types';
export const money = (n:number) => new Intl.NumberFormat('bn-BD',{style:'currency',currency:'BDT',maximumFractionDigits:2}).format(n || 0);
export const dateLabel = (d:string) => d ? new Date(`${d}T12:00:00`).toLocaleDateString('bn-BD') : '—';
export function shares(investors: Investor[], entries: Entry[]) {
  const capital = new Map<string,number>();
  for (const i of investors) capital.set(i.id,0);
  for (const e of entries) if (e.type==='investment' && e.status==='posted' && e.investorId && capital.has(e.investorId)) capital.set(e.investorId,(capital.get(e.investorId)||0)+e.amount);
  const total=[...capital.values()].reduce((a,b)=>a+b,0);
  return investors.map(i=>({ ...i, capital:capital.get(i.id)||0, share:total ? (capital.get(i.id)||0)/total*100 : 0 }));
}
export function summary(entries: Entry[]) {
  const posted=entries.filter(e=>e.status==='posted');
  const sum=(type:Entry['type'])=>posted.filter(e=>e.type===type).reduce((s,e)=>s+e.amount,0);
  const sales=sum('sale'), purchases=sum('purchase'), expenses=sum('expense'), investments=sum('investment'), withdrawals=sum('withdrawal');
  return {sales,purchases,expenses,investments,withdrawals,roughNetProfit:sales-purchases-expenses};
}
export function csvEscape(v:unknown) { const s=String(v??''); return `"${s.replaceAll('"','""')}"`; }