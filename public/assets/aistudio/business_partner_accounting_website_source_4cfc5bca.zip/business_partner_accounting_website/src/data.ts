import { addDoc, collection, deleteDoc, doc, getDocs, onSnapshot, query, serverTimestamp, updateDoc, where, writeBatch, type Unsubscribe } from 'firebase/firestore';
import { db } from './firebase';
import type { Entry, Investor } from './types';
const requireDb=()=>{if(!db) throw new Error('Firebase সেটআপ করা হয়নি। .env ফাইল পূরণ করুন।'); return db;};
export function watchEntries(cb:(rows:Entry[])=>void, error:(e:Error)=>void):Unsubscribe {
 const d=requireDb(); return onSnapshot(collection(d,'entries'),s=>cb(s.docs.map(x=>({id:x.id,...x.data()} as Entry)).sort((a,b)=>b.date.localeCompare(a.date))),e=>error(e));
}
export function watchInvestors(cb:(rows:Investor[])=>void,error:(e:Error)=>void):Unsubscribe {
 const d=requireDb(); return onSnapshot(collection(d,'investors'),s=>cb(s.docs.map(x=>({id:x.id,...x.data()} as Investor))),e=>error(e));
}
export async function addEntry(row:Omit<Entry,'id'|'createdAt'>,uid:string) {
 return addDoc(collection(requireDb(),'entries'),{...row,createdBy:uid,createdAt:serverTimestamp()});
}
export async function addInvestor(row:Omit<Investor,'id'|'createdAt'>) {
 return addDoc(collection(requireDb(),'investors'),{...row,createdAt:serverTimestamp()});
}
export async function updateEntry(id:string,patch:Partial<Entry>) {
 await updateDoc(doc(requireDb(),'entries',id),{...patch,updatedAt:serverTimestamp()});
}
export async function removeDraftEntry(id:string) {
 const d=requireDb(); const ref=doc(d,'entries',id);
 // Draft-only hard deletion. Posted financial transactions should be reversed, not erased.
 await deleteDoc(ref);
}
export async function voidPostedEntry(entry:Entry,reason:string,uid:string) {
 const d=requireDb();
 const batch=writeBatch(d);
 batch.update(doc(d,'entries',entry.id),{status:'void',voidReason:reason,voidedBy:uid,voidedAt:serverTimestamp()});
 batch.set(doc(collection(d,'auditLogs')),{action:'void_entry',recordId:entry.id,reason,actor:uid,createdAt:serverTimestamp(),previousStatus:entry.status});
 await batch.commit();
}
export async function deleteDemoEntries() {
 const d=requireDb(); const snap=await getDocs(query(collection(d,'entries'),where('demo','==',true)));
 const batch=writeBatch(d); snap.docs.forEach(s=>batch.delete(s.ref)); await batch.commit(); return snap.size;
}