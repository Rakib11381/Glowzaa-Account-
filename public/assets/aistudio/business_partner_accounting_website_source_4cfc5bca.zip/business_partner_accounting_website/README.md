# Business Partner Accounting — Website starter

বাংলা-ভিত্তিক ব্যবসার হিসাবের ওয়েবসাইটের React + TypeScript + Firebase starter project।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি একটি কার্যকরী প্রাথমিক কোডবেস, সম্পূর্ণ audited accounting/production deployment নয়। এতে লগইন, Firestore থেকে লেনদেন/ইনভেস্টর পড়া, লেনদেন যোগ করা, শেয়ার গণনার প্রাথমিক লজিক, CSV export, draft deletion এবং posted transaction void করার UI/logic আছে। পূর্ণ inventory costing, COGS, tax, PDF বাংলা font embedding, secure Cloud Functions provisioning, full audit policy, and automated tests এখনও সম্পূর্ণ করতে হবে। বাস্তব অর্থের হিসাব চালুর আগে পরীক্ষা করুন।

## 1. Install
Node.js 20+ ইনস্টল করুন, project folder-এ terminal খুলে:
```bash
npm install
```

## 2. Firebase project
1. https://console.firebase.google.com/ এ একটি project তৈরি করুন।
2. Authentication → Sign-in method থেকে Email/Password চালু করুন।
3. Firestore Database তৈরি করুন।
4. Project settings → Your apps থেকে Web app configuration নিন।
5. `.env.example` কপি করে `.env.local` নাম দিন এবং Firebase config values বসান:
```bash
cp .env.example .env.local
```
Windows-এ ফাইলটি ম্যানুয়ালি কপি করে `.env.local` নামে রাখুন।
6. `firestore.rules` Firebase Console-এর Firestore Rules-এ review করে publish করুন।
7. প্রথম Admin এবং Investor-দের জন্য Authentication user তৈরি করুন। এরপর নিরাপদ trusted backend/Admin SDK setup দিয়ে `users/{uid}` documents তৈরি করুন:
```json
{ "role": "admin", "active": true }
```
অন্য ব্যবহারকারীদের জন্য:
```json
{ "role": "investor", "active": true }
```
**সতর্কতা:** ক্লায়েন্ট থেকে role document তৈরি করবেন না। এই starter-এ public admin setup নেই; trusted backend বা Firebase Admin SDK দিয়ে provision করতে হবে। Production-এ admin creation callable Cloud Function/secure one-time setup দিয়ে করুন।

## 3. Run locally
```bash
npm run dev
```
Vite যে local URL দেখাবে তা browser-এ খুলুন।

## 4. Build
```bash
npm run build
npm run preview
```

## 5. Deploy
Firebase Hosting ব্যবহার করতে Firebase CLI install/login করে:
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy
```
Hosting setup-এ `dist` public directory এবং single-page app rewrite নির্বাচন করুন। Firestore rules আলাদাভাবে publish করুন। Public URL-এ আসল হিসাব দেওয়ার আগে rules, authentication, backups, audit, and calculations পরীক্ষা করুন।

## Demo data cleanup
এই starter-এ Settings → “ডেমো লেনদেন মুছুন” শুধুমাত্র `entries` collection-এ `demo: true` থাকা entry মুছে। এটি investors বা অন্য collection মুছে না। Production data থাকলে আগে backup এবং review করুন। Posted transaction সাধারণত delete না করে void/reversal করতে হবে।

## Accounting notes
- Share percentage = posted equity investment / all posted equity investments.
- This starter currently stores investment entries as a generic entry type. It does not yet implement partner loans as a separate liability ledger.
- The displayed rough profit is sales minus purchase-entry total minus expenses. This is **not** a final accounting profit calculation because inventory costing/COGS and returns are not fully implemented.
- Amounts are currently JavaScript numbers. Before production, store currency as integer paisa and validate all financial operations server-side.
- PDF download is not yet implemented; CSV export is available.
- Security rules must be tested in Firebase Emulator. Never use public read/write rules.

## Suggested next prompt for Google AI Studio
"Inspect this uploaded existing React + TypeScript website project and complete it without replacing its structure. Fix all build errors. Implement the remaining accounting modules, proper integer-paisa financial calculations, stock costing and COGS, secure Cloud Functions for role provisioning and financial operations, full demo cleanup preview across collections, audit-safe deletion/reversal, Bengali PDF generation with embedded Unicode font, automated tests, and a deployment guide. Keep it a browser-only website, not a PWA or native app. Do not claim production readiness until tests pass."
